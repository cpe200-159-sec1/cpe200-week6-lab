package cpe200;

/**
 * Created by pruet on 26/9/2559.
 */
public interface IUser {
    String getUserName();
    String getPassword();
    String setUserName(String u);
    int setPassword(String p);
}
